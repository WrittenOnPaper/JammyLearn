package com.jammysoft.jammylearn;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Cursor;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.jammysoft.jammylearn.screens.Titlescreen;

import java.security.Key;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class MainGameClass extends Game implements ApplicationListener {

	// Game
	public int gameWidth = 384;
	public int gameHeight = 216;

	// Cameras and viewports
	public OrthographicCamera camera;
	public FitViewport viewport;
	private FitViewport stageViewport;

	// Sprite batches
	public BitmapFont font;
	public SpriteBatch batchGUI;
	public Stage stage;
	public Skin skin;

	// Textures
	public boolean showCursor = false;
	public Texture cursourTex;
	private Sprite cursor;



	@Override
	public void create() {

		// Cursor
		Gdx.graphics.setSystemCursor(Cursor.SystemCursor.None);

		// Cameras and viewports
		camera = new OrthographicCamera(gameWidth, gameHeight);
		stageViewport = new FitViewport(gameWidth, gameHeight);
		viewport = new FitViewport(gameWidth, gameHeight);

		// Sprite batches
		font = new BitmapFont();
		batchGUI = new SpriteBatch();

		// Stage
		stage = new Stage(stageViewport);
		skin = new Skin(Gdx.files.internal("ui/uiskin.json"));

		// Textures
		cursourTex = new Texture("Sprites/misc/cursor.png");
		cursor = new Sprite(cursourTex);

		// Switch to Splashscreen first thing
		this.setScreen(new Titlescreen(this));

	}

	@Override
	public void render() {
		// Render everything in screen
		ScreenUtils.clear(Color.BLACK);
		super.render();


		if (showCursor == true) {
			cursor.setPosition(MouseToWorld().x + 192, MouseToWorld().y + 91);
			batchGUI.begin();
			cursor.draw(batchGUI);
			batchGUI.end();
		}

		// Go to the title screen when escape is pressed



	}

	@Override
	public void resize(int width, int height) {
		viewport.update(width, height);
		stageViewport.update(width, height);
		viewport.apply();
		stageViewport.apply();
	}

	@Override
	public void dispose() {
		cursourTex.dispose();
	}

	public Vector3 MouseToWorld() {
		return viewport.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0));
	}


}