package com.jammysoft.jammylearn.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Array;

import com.jammysoft.jammylearn.MainGameClass;
import com.jammysoft.jammylearn.utils.buildScreenFunctions;
import com.jammysoft.jammylearn.utils.gameObjectClass;


import java.util.Iterator;

public class BuildRoomTest implements Screen {
    // Game
    final MainGameClass game;

    // Screen variables
    private Array<String> bitsyTextList = new Array<>();
    private int bitsyText = 0;
    private boolean bitsyCanTalk = true;
    private boolean startBuild = false;
    private Array<String> selectedBuildScreenFunction;
    private boolean functionHas2Vectors = false;
    private String selectedEvent = "";
    private buildScreenFunctions bsFunction = new buildScreenFunctions();
    private Array<String> danceBoyCreateArray = new Array<String>();
    private Array<String> danceBoyUpdateArray = new Array<String>();
    private Array<String> danceBoyUpArray = new Array<String>();
    private Array<String> danceBoyDownArray = new Array<String>();
    private Array<String> danceBoyLeftArray = new Array<String>();
    private Array<String> danceBoyRightArray = new Array<String>();
    private Array<String> danceBoyZArray = new Array<String>();
    private Array<String> danceBoyXArray = new Array<String>();


    // Sprites
    private Texture testTex = new Texture("Sprites/buildScreenSprites/danceBoy3.png");
    private Texture bitsySpeechBubble = new Texture("Sprites/GUI/speechBubble2.png");
    private Texture clickOnHer = new Texture("Sprites/GUI/clickOnHer.png");
    private Sprite testSprite = new Sprite(testTex);

    private Texture redCircle = new Texture("Sprites/GUI/buildScreen/redCircle.png");

    // Stages
    private TextButton startBuildButton;

    private Texture bitsyTex;
    private ImageButton bitsyButton;
    private TextureRegion bitsyButtonTextureRegion;
    private TextureRegionDrawable bitsyButtonTextureRegionDrawable;

    private TextField vector1Field;
    private TextField vector2Field;

    private Texture onCreateButtonTex;
    private ImageButton onCreateButton;
    private TextureRegion onCreateButtonTextureRegion;
    private TextureRegionDrawable onCreateButtonTextureRegionDrawable;

    private Texture onUpdateButtonTex;
    private ImageButton onUpdateButton;
    private TextureRegion onUpdateButtonTextureRegion;
    private TextureRegionDrawable onUpdateButtonTextureRegionDrawable;

    private Texture onUpKeyButtonTex;
    private ImageButton onUpKeyButton;
    private TextureRegion onUpKeyButtonTextureRegion;
    private TextureRegionDrawable onUpKeyButtonTextureRegionDrawable;

    private Texture onDownKeyButtonTex;
    private ImageButton onDownKeyButton;
    private TextureRegion onDownKeyButtonTextureRegion;
    private TextureRegionDrawable onDownKeyButtonTextureRegionDrawable;

    private Texture onAddCommandButtonTex;
    private ImageButton onAddCommandButton;
    private TextureRegion onAddCommandButtonTextureRegion;
    private TextureRegionDrawable onAddCommandButtonTextureRegionDrawable;

    private Texture onLeftKeyButtonTex;
    private ImageButton onLeftKeyButton;
    private TextureRegion onLeftKeyButtonTextureRegion;
    private TextureRegionDrawable onLeftKeyButtonTextureRegionDrawable;

    private Texture onRightKeyButtonTex;
    private ImageButton onRightKeyButton;
    private TextureRegion onRightKeyButtonTextureRegion;
    private TextureRegionDrawable onRightKeyButtonTextureRegionDrawable;

    private Texture setPositionButtonTex;
    private ImageButton setPositionButton;
    private TextureRegion setPositionButtonTextureRegion;
    private TextureRegionDrawable setPositionButtonTextureRegionDrawable;

    private Texture moveXButtonTex;
    private ImageButton moveXButton;
    private TextureRegion moveXButtonTextureRegion;
    private TextureRegionDrawable moveXButtonTextureRegionDrawable;

    private Texture moveYButtonTex;
    private ImageButton moveYButton;
    private TextureRegion moveYButtonTextureRegion;
    private TextureRegionDrawable moveYButtonTextureRegionDrawable;

    private Texture changeWidthButtonTex;
    private ImageButton changeWidthButton;
    private TextureRegion changeWidthButtonTextureRegion;
    private TextureRegionDrawable changeWidthButtonTextureRegionDrawable;

    private Texture changeHeightButtonTex;
    private ImageButton changeHeightButton;
    private TextureRegion changeHeightButtonTextureRegion;
    private TextureRegionDrawable changeHeightButtonTextureRegionDrawable;

    private Texture setSizeButtonTex;
    private ImageButton setSizeButton;
    private TextureRegion setSizeButtonTextureRegion;
    private TextureRegionDrawable setSizeButtonTextureRegionDrawable;



    // Sprite batches
    private ShapeRenderer shapeRenderer;
    private SpriteBatch batch;

    // Arrays
    private Array<Rectangle> gameObjectArray;


    // DanceBoy
    private void spawnDanceBoy(int x, int y, int width, int height, Texture texture) {
        Texture gameObjectTexture = new Texture("libgdx.png");
        gameObjectArray.add(new gameObjectClass().onCreate(x, y, width, height, texture));
    }

    private void eventListener(Array<String> array, Rectangle gameObject, boolean isLoop) {
        for (int i = 0; i < array.size; i++) {
            if (array.get(i) == "moveX") { // Move X
                bsFunction.moveX(gameObject, Float.parseFloat(array.get(i + 1)));
            }
            if (array.get(i) == "moveY") { // Move Y
                bsFunction.moveY(gameObject, Float.parseFloat(array.get(i + 1)));
            }
            if (array.get(i) == "setPosition") { // Set position
                bsFunction.setPosition(gameObject, new Vector2(Float.parseFloat(array.get(i + 1)), Float.parseFloat(array.get(i + 2))));
            }
            if (array.get(i) == "changeWidth") { // Change Width
                bsFunction.changeWidth(gameObject, Float.parseFloat(array.get(i + 1)));
            }
            if (array.get(i) == "changeHeight") { // Change Height
                bsFunction.changeHeight(gameObject, Float.parseFloat(array.get(i + 1)));
            }
            if (array.get(i) == "setSize") { // Set scale
                bsFunction.setSize(gameObject, new Vector2(Float.parseFloat(array.get(i + 1)), Float.parseFloat(array.get(i + 2))));
            }
        }

    }

    private void danceBoyCreate(Rectangle gameObject) {
        eventListener(danceBoyCreateArray, gameObject, false);

    }
    public void danceBoyUpdate(Rectangle gameObject) {
        eventListener(danceBoyUpdateArray, gameObject, true);
    }
    public void danceBoyUp(Rectangle gameObject) {
        eventListener(danceBoyUpArray, gameObject, true);
    }
    public void danceBoyDown(Rectangle gameObject) {
        eventListener(danceBoyDownArray, gameObject, true);
    }
    public void danceBoyLeft(Rectangle gameObject) {
        eventListener(danceBoyLeftArray, gameObject, true);
    }
    public void danceBoyRight(Rectangle gameObject) {
        eventListener(danceBoyRightArray, gameObject, true);
    }
    public void danceBoyZ(Rectangle gameObject) {
        eventListener(danceBoyZArray, gameObject, true);
    }
    public void danceBoyX(Rectangle gameObject) {
        eventListener(danceBoyXArray, gameObject, true);
    }


    public BuildRoomTest(final MainGameClass game) {

        // Game
        this.game = game;
        game.camera.position.set(0, 0, 0);
        game.camera.update();

        // Selecting array
        selectedBuildScreenFunction = danceBoyCreateArray;

        // Shape renderer
        shapeRenderer = new ShapeRenderer();

        // Sprite batch
        batch = new SpriteBatch();

        // Spawn game objects
        gameObjectArray = new Array<Rectangle>();
        spawnDanceBoy(0, 50, 16, 16, new Texture("Sprites/buildScreenSprites/danceBoy2.png"));

        // Bitsy text
        bitsyTextList.add("In JammyLearn, you will\nlearn how to code using\ncommands. Click on\nme as you do a step");
        bitsyTextList.add("Your task is to give\nDanceboy (the green shirt\nguy below) some life.");
        bitsyTextList.add("The blue button with four\narrows is the setPosition\ncommand. Click on it.");
        bitsyTextList.add("The first text field is the\nX position. The second is\nthe Y position\n(continue)");
        bitsyTextList.add("Plug in numbers in both\nfields like you would with\ncoordinates in math class\nthen click that + button");
        bitsyTextList.add("The onCreate function\nexecutes when the Start\nBuild button is clicked. It\nonly runs once. (continue)");
        bitsyTextList.add("Click Start Build to\nrun.");
        bitsyTextList.add("Danceboy will now start\nat that point from now on.\n(continue)");
        bitsyTextList.add("Our app is still boring.\nWe'll have Danceboy move\nwhen an arrow key is\npressed. (continue)");
        bitsyTextList.add("Click the onRightKey\nfunction.");
        bitsyTextList.add("Give the function a moveX\ncommand.");
        bitsyTextList.add("Our room is small, so give\nthe first field a number\nbelow 10. After that, press\nthe + button.");
        bitsyTextList.add("Now hit restart the build and\npress the right arrow key.");
        bitsyTextList.add("Nice work! Free time's\nyours. Thank you for\nchecking out JammyLearn!");

        // On creation
        //danceBoyCreateArray.add("setPosition");
        //danceBoyCreateArray.add("0");
        //danceBoyCreateArray.add("0");
        //danceBoyCreateArray.add("setSize");
        //danceBoyCreateArray.add("16");
        //danceBoyCreateArray.add("16");

        // On up
        //danceBoyUpArray.add("moveY");
        //danceBoyUpArray.add("1");

        // On down
        //danceBoyDownArray.add("moveY");
        //danceBoyDownArray.add("-1");

        // On left
        //danceBoyLeftArray.add("moveX");
        //danceBoyLeftArray.add("-1");

        // On right
        //danceBoyRightArray.add("moveX");
        //danceBoyRightArray.add("1");

        // On Z
        //danceBoyZArray.add("changeWidth");
        //danceBoyZArray.add("1");

        // On X
        //danceBoyXArray.add("changeHeight");
        //danceBoyXArray.add("1");


        // Stage
        bitsyTex = new Texture("Sprites/characters/bitsy/bitsyTiny1.png");
        bitsyButtonTextureRegion = new TextureRegion(bitsyTex);
        bitsyButtonTextureRegionDrawable = new TextureRegionDrawable(bitsyButtonTextureRegion);
        bitsyButton = new ImageButton(bitsyButtonTextureRegionDrawable);
        bitsyButton.setPosition(101, 116);
        bitsyButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (bitsyCanTalk == true && bitsyText < bitsyTextList.size - 1) {
                    bitsyText += 1;
                }
            }
        });
        game.stage.addActor(bitsyButton);

        vector1Field = new TextField("0", game.skin);
        vector1Field.setPosition(125, 18);
        vector1Field.setScale(1f, 1f);
        vector1Field.setSize(30, 14);
        //game.stage.addActor(vector1Field);

        vector2Field = new TextField("0", game.skin);
        vector2Field.setPosition(158, 18);
        vector2Field.setScale(1f, 1f);
        vector2Field.setSize(30, 14);
        //game.stage.addActor(vector2Field);


        startBuildButton = new TextButton("Start build", game.skin, "default");
        startBuildButton.setTransform(true);
        startBuildButton.setSize(70, 10);
        startBuildButton.setScale(1, 1);
        startBuildButton.setPosition(0,116);
        startBuildButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                for (Iterator<Rectangle> iter = gameObjectArray.iterator(); iter.hasNext();) {
                    Rectangle gameObject = iter.next();
                    // Set sprite properties
                    testSprite.setPosition(gameObject.x, gameObject.y);
                    testSprite.setSize(gameObject.width, gameObject.height);

                    danceBoyCreate(gameObject);
                }
            }
        });
        game.stage.addActor(startBuildButton);

        onAddCommandButtonTex = new Texture("Sprites/GUI/buildScreen/addCommandButton.png");
        onAddCommandButtonTextureRegion = new TextureRegion(onAddCommandButtonTex);
        onAddCommandButtonTextureRegionDrawable = new TextureRegionDrawable(onAddCommandButtonTextureRegion);
        onAddCommandButton = new ImageButton(onAddCommandButtonTextureRegionDrawable);
        onAddCommandButton.setPosition(game.gameWidth - onAddCommandButton.getWidth(), 0);
        onAddCommandButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (selectedEvent == "setPosition") {
                    selectedBuildScreenFunction.add("setPosition");
                    selectedBuildScreenFunction.add(vector1Field.getText());
                    selectedBuildScreenFunction.add(vector2Field.getText());
                }

                if (selectedEvent == "moveX") {
                    selectedBuildScreenFunction.add("moveX");
                    selectedBuildScreenFunction.add(vector1Field.getText());
                }

                if (selectedEvent == "moveY") {
                    selectedBuildScreenFunction.add("moveY");
                    selectedBuildScreenFunction.add(vector1Field.getText());
                }

                if (selectedEvent == "changeWidth") {
                    selectedBuildScreenFunction.add("changeWidth");
                    selectedBuildScreenFunction.add(vector1Field.getText());
                }

                if (selectedEvent == "changeHeight") {
                    selectedBuildScreenFunction.add("changeHeight");
                    selectedBuildScreenFunction.add(vector1Field.getText());
                }

                if (selectedEvent == "setSize") {
                    selectedBuildScreenFunction.add("setSize");
                    selectedBuildScreenFunction.add(vector1Field.getText());
                    selectedBuildScreenFunction.add(vector2Field.getText());
                }


            }
        });
        game.stage.addActor(onAddCommandButton);


        onCreateButtonTex = new Texture("Sprites/GUI/buildScreen/onCreate.png");
        onCreateButtonTextureRegion = new TextureRegion(onCreateButtonTex);
        onCreateButtonTextureRegionDrawable = new TextureRegionDrawable(onCreateButtonTextureRegion);
        onCreateButton = new ImageButton(onCreateButtonTextureRegionDrawable);
        onCreateButton.setPosition(184, 200);
        onCreateButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedBuildScreenFunction = danceBoyCreateArray;

            }
        });
        game.stage.addActor(onCreateButton);

        // Stage
        onUpdateButtonTex = new Texture("Sprites/GUI/buildScreen/onUpdate.png");
        onUpdateButtonTextureRegion = new TextureRegion(onUpdateButtonTex);
        onUpdateButtonTextureRegionDrawable = new TextureRegionDrawable(onUpdateButtonTextureRegion);
        onUpdateButton = new ImageButton(onUpdateButtonTextureRegionDrawable);
        onUpdateButton.setPosition(200, 200);
        onUpdateButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedBuildScreenFunction = danceBoyUpdateArray;
            }
        });
        game.stage.addActor(onUpdateButton);

        onUpKeyButtonTex = new Texture("Sprites/GUI/buildScreen/onUpKey.png");
        onUpKeyButtonTextureRegion = new TextureRegion(onUpKeyButtonTex);
        onUpKeyButtonTextureRegionDrawable = new TextureRegionDrawable(onUpKeyButtonTextureRegion);
        onUpKeyButton = new ImageButton(onUpKeyButtonTextureRegionDrawable);
        onUpKeyButton.setPosition(184, 184);
        onUpKeyButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedBuildScreenFunction = danceBoyUpArray;
            }
        });
        game.stage.addActor(onUpKeyButton);

        onDownKeyButtonTex = new Texture("Sprites/GUI/buildScreen/onDownKey.png");
        onDownKeyButtonTextureRegion = new TextureRegion(onDownKeyButtonTex);
        onDownKeyButtonTextureRegionDrawable = new TextureRegionDrawable(onDownKeyButtonTextureRegion);
        onDownKeyButton = new ImageButton(onDownKeyButtonTextureRegionDrawable);
        onDownKeyButton.setPosition(200, 184);
        onDownKeyButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedBuildScreenFunction = danceBoyDownArray;
            }
        });
        game.stage.addActor(onDownKeyButton);

        onLeftKeyButtonTex = new Texture("Sprites/GUI/buildScreen/onLeftKey.png");
        onLeftKeyButtonTextureRegion = new TextureRegion(onLeftKeyButtonTex);
        onLeftKeyButtonTextureRegionDrawable = new TextureRegionDrawable(onLeftKeyButtonTextureRegion);
        onLeftKeyButton = new ImageButton(onLeftKeyButtonTextureRegionDrawable);
        onLeftKeyButton.setPosition(216, 184);
        onLeftKeyButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedBuildScreenFunction = danceBoyLeftArray;
            }
        });

        game.stage.addActor(onLeftKeyButton);

        onRightKeyButtonTex = new Texture("Sprites/GUI/buildScreen/onRightKey.png");
        onRightKeyButtonTextureRegion = new TextureRegion(onRightKeyButtonTex);
        onRightKeyButtonTextureRegionDrawable = new TextureRegionDrawable(onRightKeyButtonTextureRegion);
        onRightKeyButton = new ImageButton(onRightKeyButtonTextureRegionDrawable);
        onRightKeyButton.setPosition(232, 184);
        onRightKeyButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedBuildScreenFunction = danceBoyRightArray;
            }
        });
        game.stage.addActor(onRightKeyButton);

        setPositionButtonTex = new Texture("Sprites/GUI/buildScreen/setPosition.png");
        setPositionButtonTextureRegion = new TextureRegion(setPositionButtonTex);
        setPositionButtonTextureRegionDrawable = new TextureRegionDrawable(setPositionButtonTextureRegion);
        setPositionButton = new ImageButton(setPositionButtonTextureRegionDrawable);
        setPositionButton.setPosition(120, 0);
        setPositionButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedEvent = "setPosition";
                vector1Field.setText("0");
                vector2Field.setText("0");
                vector1Field.remove();
                vector2Field.remove();
                game.stage.addActor(vector1Field);
                game.stage.addActor(vector2Field);
            }
        });
        game.stage.addActor(setPositionButton);

        moveXButtonTex = new Texture("Sprites/GUI/buildScreen/moveX.png");
        moveXButtonTextureRegion = new TextureRegion(moveXButtonTex);
        moveXButtonTextureRegionDrawable = new TextureRegionDrawable(moveXButtonTextureRegion);
        moveXButton = new ImageButton(moveXButtonTextureRegionDrawable);
        moveXButton.setPosition(137, 0);
        moveXButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedEvent = "moveX";
                vector1Field.setText("0");
                vector2Field.setText("0");
                vector1Field.remove();
                vector2Field.remove();
                game.stage.addActor(vector1Field);
            }
        });
        game.stage.addActor(moveXButton);

        moveYButtonTex = new Texture("Sprites/GUI/buildScreen/moveY.png");
        moveYButtonTextureRegion = new TextureRegion(moveYButtonTex);
        moveYButtonTextureRegionDrawable = new TextureRegionDrawable(moveYButtonTextureRegion);
        moveYButton = new ImageButton(moveYButtonTextureRegionDrawable);
        moveYButton.setPosition(154, 0);
        moveYButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedEvent = "moveY";
                vector1Field.setText("0");
                vector2Field.setText("0");
                vector1Field.remove();
                vector2Field.remove();
                game.stage.addActor(vector1Field);
            }
        });
        game.stage.addActor(moveYButton);

        changeWidthButtonTex = new Texture("Sprites/GUI/buildScreen/changeWidth.png");
        changeWidthButtonTextureRegion = new TextureRegion(changeWidthButtonTex);
        changeWidthButtonTextureRegionDrawable = new TextureRegionDrawable(changeWidthButtonTextureRegion);
        changeWidthButton = new ImageButton(changeWidthButtonTextureRegionDrawable);
        changeWidthButton.setPosition(171, 0);
        changeWidthButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedEvent = "changeWidth";
                vector1Field.setText("0");
                vector2Field.setText("0");
                vector1Field.remove();
                vector2Field.remove();
                game.stage.addActor(vector1Field);
            }
        });
        game.stage.addActor(changeWidthButton);

        changeHeightButtonTex = new Texture("Sprites/GUI/buildScreen/changeHeight.png");
        changeHeightButtonTextureRegion = new TextureRegion(changeHeightButtonTex);
        changeHeightButtonTextureRegionDrawable = new TextureRegionDrawable(changeHeightButtonTextureRegion);
        changeHeightButton = new ImageButton(changeHeightButtonTextureRegionDrawable);
        changeHeightButton.setPosition(188, 0);
        changeHeightButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedEvent = "changeHeight";
                vector1Field.setText("0");
                vector2Field.setText("0");
                vector1Field.remove();
                vector2Field.remove();
                game.stage.addActor(vector1Field);
            }
        });
        game.stage.addActor(changeHeightButton);

        setSizeButtonTex = new Texture("Sprites/GUI/buildScreen/setSize.png");
        setSizeButtonTextureRegion = new TextureRegion(setSizeButtonTex);
        setSizeButtonTextureRegionDrawable = new TextureRegionDrawable(setSizeButtonTextureRegion);
        setSizeButton = new ImageButton(setSizeButtonTextureRegionDrawable);
        setSizeButton.setPosition(205, 0);
        setSizeButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                selectedEvent = "setSize";
                vector1Field.setText("0");
                vector2Field.setText("0");
                vector1Field.remove();
                vector2Field.remove();
                game.stage.addActor(vector1Field);
                game.stage.addActor(vector2Field);
            }
        });
        game.stage.addActor(setSizeButton);




        Gdx.input.setInputProcessor(game.stage);

    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        // Game
        game.camera.position.set(0, 0, 0);
        game.camera.update();

        // Draw shapes
        shapeRenderer.setProjectionMatrix(game.camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.WHITE); // Draw the game screen background
        shapeRenderer.rect(-(game.gameWidth / 2), -(game.gameHeight / 2), 120, 120);
        shapeRenderer.end();

        // Update object sprites arrays
        batch.setProjectionMatrix(game.camera.combined);
        batch.begin();
        for (Iterator<Rectangle> iter = gameObjectArray.iterator(); iter.hasNext();) {
            Rectangle gameObject = iter.next();
            // Set sprite properties
            testSprite.setPosition(gameObject.x, gameObject.y);
            testSprite.setSize(gameObject.width, gameObject.height);

            // Draw
            testSprite.draw(batch);
        }
        batch.end();


        // Update object rect arrays
        for (Iterator<Rectangle> iter = gameObjectArray.iterator(); iter.hasNext();) {
            Rectangle gameObject = iter.next();
            if (startBuild == true) {
                // Always update
                danceBoyUpdate(gameObject);

                // Input updates
                if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
                    danceBoyUp(gameObject);
                }
                if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
                    danceBoyDown(gameObject);
                }
                if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
                    danceBoyLeft(gameObject);
                }
                if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
                    danceBoyRight(gameObject);
                }
                if (Gdx.input.isKeyPressed(Input.Keys.Z)) {
                    danceBoyZ(gameObject);
                }
                if (Gdx.input.isKeyPressed(Input.Keys.X)) {
                    danceBoyX(gameObject);
                }
            }
        }

        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.DARK_GRAY); // Draw the editor background
        shapeRenderer.rect(-200, 8, 9999, 9999);
        shapeRenderer.rect(-72, -200, 9999, 9999);
        shapeRenderer.end();


        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.LIGHT_GRAY); // Draw the tray for buttons
        shapeRenderer.rect(-8, 76, 200, 40);
        shapeRenderer.end();

        // Toggle startBuild
        startBuild = startBuildButton.isChecked();
        if (startBuildButton.isChecked() == true) {
            startBuildButton.setText("Stop build");
        }
        else {
            startBuildButton.setText("Start build");
        }

        // Let user know that a function is selected
        if (selectedBuildScreenFunction == danceBoyCreateArray) {onCreateButton.setY(205);}
        else {onCreateButton.setY(200);}
        if (selectedBuildScreenFunction == danceBoyUpdateArray) {onUpdateButton.setY(205);}
        else {onUpdateButton.setY(200);}
        if (selectedBuildScreenFunction == danceBoyUpArray) {onUpKeyButton.setY(189);}
        else {onUpKeyButton.setY(184);}
        if (selectedBuildScreenFunction == danceBoyDownArray) {onDownKeyButton.setY(189);}
        else {onDownKeyButton.setY(184);}
        if (selectedBuildScreenFunction == danceBoyLeftArray) {onLeftKeyButton.setY(189);}
        else {onLeftKeyButton.setY(184);}
        if (selectedBuildScreenFunction == danceBoyRightArray) {onRightKeyButton.setY(189);}
        else {onRightKeyButton.setY(184);}

        // List actions
        batch.begin();
        game.font.setColor(Color.BLACK);
        for (int i = 0; i < selectedBuildScreenFunction.size; i++) {
            // Let the user know there is no list
            if (selectedBuildScreenFunction.size == 0) {
                game.font.draw(batch, "No items. Sad..", 0, 0);
            }
            else {
                game.font.draw(batch, selectedBuildScreenFunction.get(i), 0, 70 + (i * -15));
            }
        }
        batch.end();

        // Bitsy's speech
        batch.begin();
        batch.draw(bitsySpeechBubble, -192, 33);
        batch.draw(clickOnHer, -120, 18);
        game.font.setColor(Color.GREEN);
        game.font.draw(batch, bitsyTextList.get(bitsyText), -191, 108);
        batch.end();


        // Stage
        game.stage.act(Gdx.graphics.getDeltaTime());
        game.stage.draw();

        // Draw red circle
        batch.begin();
        if (bitsyText == 1) {
            batch.draw(redCircle, testSprite.getX(), testSprite.getY());
        }
        else if (bitsyText == 2) {
            batch.draw(redCircle, -72, -game.gameHeight / 2);
        }
        else if (bitsyText == 4) {
            batch.draw(redCircle, 176, -game.gameHeight / 2);
        }
        else if (bitsyText == 5) {
            batch.draw(redCircle, -8, 92);
        }
        else if (bitsyText == 6) {
            batch.draw(redCircle, -150, 5);
        }
        else if (bitsyText == 7) {
            batch.draw(redCircle, Float.parseFloat(vector1Field.getText()) - 192, Float.parseFloat(vector2Field.getText()) - 108);
        }
        else if (bitsyText == 9) {
            batch.draw(redCircle, 40, 76);
        }
        else if (bitsyText == 10) {
            batch.draw(redCircle, -55, -game.gameHeight / 2);
        }
        else if (bitsyText == 11) {
            batch.draw(redCircle, 176, -game.gameHeight / 2);
        }
        else if (bitsyText == 12) {
            batch.draw(redCircle, -150, 5);
        }
        batch.end();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
