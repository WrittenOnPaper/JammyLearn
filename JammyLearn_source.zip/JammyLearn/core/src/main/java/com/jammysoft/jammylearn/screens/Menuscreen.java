package com.jammysoft.jammylearn.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Array;
import com.jammysoft.jammylearn.MainGameClass;

import java.util.Iterator;

public class Menuscreen implements Screen {

    // Game
    final MainGameClass game;

    // Textures and sprites
    private SpriteBatch batch;
    private Texture bitsyTex1;
    private Texture bitsyTex2;
    private Sprite bitsy;
    private Texture speechBubbleTex;

    private Texture backgroundTilesTex;

    // Arrays
    private Array<Rectangle> backgroundTiles;
    private Array<String> bitsyTextList;
    private int bitsyText = 0;

    // Stage
    private TextButton playLessonButton;
    private TextButton studioButton;
    private TextButton quitButton;

    private void spawnBackgroundTile(int x, int y) {
        Rectangle backgroundTile = new Rectangle();
        backgroundTile.x = x + -(game.viewport.getWorldWidth() / 2);
        backgroundTile.y = y + -(game.viewport.getWorldHeight() / 2);
        backgroundTile.width = 64;
        backgroundTile.height = 64;
        backgroundTiles.add(backgroundTile);
    }



    public Menuscreen(final MainGameClass game) {
        // Game
        this.game = game;
        game.camera.position.set(0, 0, 0);
        game.camera.update();

        // Textures and sprites
        batch = new SpriteBatch();
        bitsyTex1 = new Texture("Sprites/characters/bitsy/bitsy1.png");
        bitsyTex2 = new Texture("Sprites/characters/bitsy/bitsy2.png");
        bitsy = new Sprite(bitsyTex1);
        bitsy.setPosition(-(game.viewport.getWorldWidth() / 2), -(game.viewport.getWorldHeight() / 2));

        speechBubbleTex = new Texture("Sprites/GUI/speechBubble.png");

        backgroundTilesTex = new Texture("Sprites/backgrounds/menuScreenTiles.png");

        // Background
        backgroundTiles = new Array<Rectangle>();
        spawnBackgroundTile(-(backgroundTilesTex.getWidth() / 2), 0);
        spawnBackgroundTile(0, 0);

        // Text
        bitsyTextList = new Array<String>();
        bitsyTextList.add("Hover over a\nbutton to get\nit's details!");
        bitsyTextList.add("Make the\ndance boy\ndance!");
        bitsyTextList.add("Like\nJammyLearn?\nCheck out our\nother stuff!");
        bitsyTextList.add("Leaving so\nsoon?");

        // Stage
        playLessonButton = new TextButton("Play coding lesson", game.skin, "default");
        playLessonButton.setTransform(true);
        playLessonButton.setSize(140, 10);
        playLessonButton.setScale(1, 1);
        playLessonButton.setPosition(110,120);
        playLessonButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                quitButton.remove();
                studioButton.remove();
                playLessonButton.remove();
                game.setScreen(new BuildRoomTest(game));
            }
        });
        game.stage.addActor(playLessonButton);


        studioButton = new TextButton("JammySoft website", game.skin, "default");
        studioButton.setTransform(true);
        studioButton.setSize(140, 10);
        studioButton.setScale(1, 1);
        studioButton.setPosition(110,100);
        studioButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.net.openURI("https://jammysoft.itch.io/");
            }
        });
        game.stage.addActor(studioButton);

        quitButton = new TextButton("Exit JammyLearn", game.skin, "default");
        quitButton.setTransform(true);
        quitButton.setSize(140, 10);
        quitButton.setScale(1, 1);
        quitButton.setPosition(110,80);
        quitButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });
        game.stage.addActor(quitButton);


        Gdx.input.setInputProcessor(game.stage);


    }


    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        // Game
        game.camera.position.set(0, 0, 0);
        game.camera.update();

        // Scroll background tiles
        for (Iterator<Rectangle> iter = backgroundTiles.iterator(); iter.hasNext(); ) {
            Rectangle backgroundTile = iter.next();
            backgroundTile.x += 1;

            if (backgroundTile.x >= 0) {
                backgroundTile.x = -(backgroundTilesTex.getWidth() / 2) + -(game.viewport.getWorldWidth() / 2);
            }
        }


        // Draw background tiles
        batch.begin();
        for(Rectangle backgroundTile: backgroundTiles) {
            batch.draw(backgroundTilesTex, backgroundTile.x, backgroundTile.y);
        }
        batch.end();

        // Sprites
        batch.setProjectionMatrix(game.camera.combined);
        batch.begin();
        bitsy.draw(batch);
        batch.end();

        // Speech
        batch.begin();
        batch.draw(speechBubbleTex, -185, -10);
        game.font.setColor(Color.BLACK);
        game.font.draw(batch, bitsyTextList.get(bitsyText), -180, 96);
        batch.end();

        // Change speech depending on button
        if (playLessonButton.isOver() == true) {
            bitsyText = 1;
        }
        else if (studioButton.isOver() == true) {
            bitsyText = 2;
        }
        else if (quitButton.isOver() == true) {
            bitsyText = 3;
        }
        else {
            bitsyText = 0;
        }

        // Change bitsy's sprite
        if (quitButton.isOver() == true) {
            bitsy.setTexture(bitsyTex2);
        }
        else {
            bitsy.setTexture(bitsyTex1);
        }

        // Stage
        game.stage.act(Gdx.graphics.getDeltaTime());
        game.stage.draw();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
