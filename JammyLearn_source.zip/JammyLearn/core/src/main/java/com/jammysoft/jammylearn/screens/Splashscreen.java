package com.jammysoft.jammylearn.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.jammysoft.jammylearn.MainGameClass;

public class Splashscreen implements Screen {

    // Game
    final MainGameClass game;

    // Screen variables
    private float cameraXPos = 0;


    private boolean gameStart = false;

    // Stage
    private Texture goButtonTex;
    private TextButton goButton;


    // Sprite batches
    private ShapeRenderer shapeRenderer;
    private SpriteBatch batch;

    // Textures and sprites
    private Texture titleLogoTex;
    private Sprite titleLogoSprite;

    public Splashscreen(final MainGameClass game) {
        // Game
        this.game = game;
        game.camera.position.set(0, 0, 0);
        game.camera.update();

        // Shape renderer
        shapeRenderer = new ShapeRenderer();

        // Sprite batches
        batch = new SpriteBatch();

        // Textures and sprites
        titleLogoTex = new Texture("Sprites/misc/jammyLearnLogo.png");
        titleLogoSprite = new Sprite(titleLogoTex);
        titleLogoSprite.setOrigin(titleLogoTex.getWidth() / 2, titleLogoTex.getHeight() / 2);
        titleLogoSprite.setPosition(0 - titleLogoSprite.getOriginX(), 0);

        // Stage
        goButton = new TextButton("GO!", game.skin, "default");
        goButton.setTransform(true);
        goButton.setSize(45, 24);
        goButton.setScale(1, 1);
        goButton.setPosition(game.gameWidth - goButton.getWidth(),0);
        goButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                gameStart = true;
                goButton.remove();
            }
        });
        game.stage.addActor(goButton);


        Gdx.input.setInputProcessor(game.stage);
    }


    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        // Game
        game.camera.position.set(cameraXPos, 0, 0);
        game.camera.update();

        // When the game starts
        if (gameStart == true) {
            // Move camera
            cameraXPos += 1;
        }

        // Draw shapes
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(216/255f, 150/255f, 100/255f, 1);
        shapeRenderer.rect(0, 0, game.gameWidth, game.gameHeight);
        shapeRenderer.end();

        // Draw sprites
        batch.setProjectionMatrix(game.camera.combined);
        batch.begin();
        titleLogoSprite.draw(batch);
        batch.end();

        // Stage
        game.stage.act(Gdx.graphics.getDeltaTime());
        game.stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
