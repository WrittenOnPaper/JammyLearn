package com.jammysoft.jammylearn.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Cursor;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.jammysoft.jammylearn.MainGameClass;

public class Titlescreen implements Screen {

    // Game
    final MainGameClass game;

    // Screen variables
    private float cameraXPos = 0;
    private boolean gameStart = false;
    private boolean isStamped = false;
    private float titleX = 0;
    private float titleY = 0;

    // Stage
    private Texture goButtonTex;
    private ImageButton goButton;
    private TextureRegion goButtonTextureRegion;
    private TextureRegionDrawable goButtonTextureRegionDrawable;


    // Sprite batches
    private ShapeRenderer shapeRenderer;
    private SpriteBatch batch;
    private int background2Height = -170;

    // Textures and sprites
    private Texture classroomBackgroundTex;
    private Texture titleLogoTex1;
    private Texture titleLogoTex2;
    private Sprite titleLogoSprite;

    public Titlescreen(final MainGameClass game) {
        // Game
        this.game = game;
        game.camera.position.set(0, 0, 0);
        game.camera.update();

        // Shape renderer
        shapeRenderer = new ShapeRenderer();

        // Sprite batches
        batch = new SpriteBatch();

        // Textures and sprites
        classroomBackgroundTex = new Texture("Sprites/backgrounds/classroom.png");

        titleLogoTex1 = new Texture("Sprites/misc/jammyLearnLogo.png");
        titleLogoTex2 = new Texture("Sprites/misc/jammyLearnLogoOutline.png");
        titleLogoSprite = new Sprite(titleLogoTex2);
        titleLogoSprite.setOrigin(titleLogoTex1.getWidth() / 2, titleLogoTex1.getHeight() / 2);
        titleLogoSprite.setPosition(0 - titleLogoSprite.getOriginX(), 0);

        // Stage
        goButtonTex = new Texture("Sprites/GUI/buildScreen/goButton.png");
        goButtonTextureRegion = new TextureRegion(goButtonTex);
        goButtonTextureRegionDrawable = new TextureRegionDrawable(goButtonTextureRegion);
        goButton = new ImageButton(goButtonTextureRegionDrawable);
        goButton.setTransform(true);
        goButton.setScale(2, 2);
        goButton.setPosition(game.gameWidth - goButton.getWidth() * goButton.getScaleX(),0);
        goButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new Menuscreen(game));
                gameStart = true;
                goButton.remove();
            }
        });


        Gdx.input.setInputProcessor(game.stage);
    }


    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        // Game
        game.camera.position.set(cameraXPos, 0, 0);
        game.camera.update();

        // When the game starts
        if (gameStart == true) {
            // Move camera
            cameraXPos += 1;
        }


        // Change title's properties if not stamped
        titleLogoSprite.setPosition(titleX, titleY);
        if (isStamped == false) {
            titleX = game.MouseToWorld().x - titleLogoTex1.getWidth() / 2;
            titleY = game.MouseToWorld().y - titleLogoTex1.getHeight() / 2;
            titleLogoSprite.setRotation(-game.MouseToWorld().x / 2);
            titleLogoSprite.setScale((-game.MouseToWorld().y + 120) / 100, (-game.MouseToWorld().y + 120) / 100);
            titleLogoSprite.setTexture(titleLogoTex2);
        }
        else {
            titleLogoSprite.setTexture(titleLogoTex1);
            background2Height += 5; // Raise background

            // Shrink logo
            if (titleLogoSprite.getScaleY() > 1) {
                titleLogoSprite.scale(-0.1f);
            }

            if (titleLogoSprite.getY() < 0) {
                titleY += 2;
            }
        }
        // Stamp title
        if (Gdx.input.justTouched()) {
            game.showCursor = true;
            game.stage.addActor(goButton);
            isStamped = true;
        }


        // Draw shapes
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(196/255f, 130/255f, 80/255f, 1); // Draw the background
        shapeRenderer.rect(0, 0, game.gameWidth, game.gameHeight);
        shapeRenderer.end();

        // Draw background
        batch.begin();
        batch.draw(classroomBackgroundTex, -(game.gameWidth / 2), -(game.gameHeight / 2));
        batch.end();

        // Draw s'more shapes
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(Color.BLACK);
        shapeRenderer.rect(0, background2Height, 999, 999);
        shapeRenderer.end();

        // Draw sprites
        batch.setProjectionMatrix(game.camera.combined);
        batch.begin();
        titleLogoSprite.draw(batch);
        batch.end();

        // Draw text
        batch.begin();
        if (isStamped == false) {
            game.font.draw(batch, "You're allowed to play this app!\nClick 2 Stamp!", -game.gameWidth / 2, 0);
        }
        batch.end();

        // Stage
        game.stage.act(Gdx.graphics.getDeltaTime());
        game.stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
