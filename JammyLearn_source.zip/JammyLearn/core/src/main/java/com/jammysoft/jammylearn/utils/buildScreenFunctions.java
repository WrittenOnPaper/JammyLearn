package com.jammysoft.jammylearn.utils;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import java.util.function.Function;

public class buildScreenFunctions {
    // !TRANSFORM BLOCKS!
    public void moveX(Rectangle gameObject, float val1) { // Move x
        gameObject.x += val1;
    }
    public void moveY(Rectangle gameObject, float val1) { // Move y
        gameObject.y += val1;
    }
    public void setPosition(Rectangle gameObject, Vector2 position) { // Set position
        gameObject.x = position.x - 192;
        gameObject.y = position.y - 108;
        Vector2 returnPosition = position;
    }
    public void changeWidth(Rectangle gameObject, float val1) { // Change width
        gameObject.width += val1;
    }
    public void changeHeight(Rectangle gameObject, float val1) { // Change height
        gameObject.height += val1;
    }
    public void setSize(Rectangle gameObject, Vector2 size) { // Set position
        gameObject.width = size.x;
        gameObject.height = size.y;
        Vector2 returnPosition = size;
    }
}
