package com.jammysoft.jammylearn.utils;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;

public class gameObjectClass {
    private Rectangle gameObject = new Rectangle();
    //public Texture texture = new Texture("Sprites/buildScreenSprites/danceBoy1.png");

    public Rectangle onCreate(int x, int y, int width, int height, Texture texture) {
        gameObject.x = x - 128;
        gameObject.y = y - 112;
        gameObject.width = width;
        gameObject.height = height;
        //this.texture = texture;

        return gameObject;
    }
}